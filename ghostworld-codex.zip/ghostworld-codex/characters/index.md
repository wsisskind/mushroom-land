# Characters

Central figures in Ghostworld.