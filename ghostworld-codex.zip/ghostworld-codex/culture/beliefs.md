# §3.4 — Beliefs & Values

Ghostworld is not built on creed but on contract — the social kind.  
The belief system here is procedural: agreements, codes, mutual obligations.  
Spirituality exists, but it is a personal, almost private affair.

---

## Common Tenets
- **The Right of Repair** — anything can be fixed by anyone who claims the responsibility.
- **No Useless Work** — all labor must justify itself to the collective.
- **Spiral Hospitality** — strangers are welcomed until they prove otherwise.

---

## Divergences
Some communes interpret Spiral Hospitality as a strict duty; others as a polite fiction.
